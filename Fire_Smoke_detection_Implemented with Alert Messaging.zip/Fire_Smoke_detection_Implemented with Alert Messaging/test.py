import winsound
winsound.Beep(1500,5000)