import twilio
import cv2
from ultralytics import YOLO
import torch
import time
import winsound
import threading
from twilio.rest import Client
from twilio.base.exceptions import TwilioRestException

# Force CPU usage
torch.cuda.is_available = lambda : False

# Load the YOLOv8 model
model = YOLO('fire_and_smoke_detection/best.pt')

# Open the video file
video_path = "D:/Sem 5 Subjects/Kuronami/fire_and_smoke_detection/Fire demo.mp4"
cap = cv2.VideoCapture(video_path)

# Fire detection tracking
fire_detected = False
detection_start_time = None
fire_detection_threshold = 3  # seconds

# Twilio configuration
account_sid = 'AC3d79a45eae5a8b158af85c6331f884f7'
auth_token = 'feb96f607a8d6b985c9ce6d2516d8b4a'
client = Client(account_sid, auth_token)
from_whatsapp_number = 'whatsapp:+14155238886'
to_whatsapp_number = 'whatsapp:+919764817663'

def draw_box(img, box, label, color):
    x1, y1, x2, y2 = box
    cv2.rectangle(img, (int(x1), int(y1)), (int(x2), int(y2)), color, 2)
    cv2.putText(img, label, (int(x1), int(y1) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, color, 2)

def high_pitched_beep():
    frequency = 1500
    duration = 3000
    winsound.Beep(frequency, duration)

def send_whatsapp_alert():
    try:
        message = client.messages.create(
            body='Fire detected for more than 3 seconds!',
            from_=from_whatsapp_number,
            to=to_whatsapp_number
        )
        print(f"WhatsApp alert sent: {message.sid}")
    except TwilioRestException as e:
        print(f"Failed to send WhatsApp alert: {str(e)}")
    except Exception as e:
        print(f"An unexpected error occurred while sending WhatsApp alert: {str(e)}")

while cap.isOpened():
    success, frame = cap.read()
    if success:
        try:
            results = model(frame, device='cpu')

            fire_detected = False
            for r in results:
                for box in r.boxes:
                    x1, y1, x2, y2 = box.xyxy[0].tolist()
                    conf = float(box.conf)
                    cls = int(box.cls)
                    class_name = model.names[cls]

                    label = f"{class_name} {conf:.2f}"
                    
                    if class_name.lower() == 'fire':
                        color = (0, 0, 255)  # Red for fire
                        fire_detected = True
                    elif class_name.lower() == 'smoke':
                        color = (128, 128, 128)  # Grey for smoke
                    else:
                        color = (0, 255, 0)  # Green for other detections

                    draw_box(frame, (x1, y1, x2, y2), label, color)

            current_time = time.time()
            if fire_detected:
                if detection_start_time is None:
                    detection_start_time = current_time
                elif current_time - detection_start_time >= fire_detection_threshold:
                    threading.Thread(target=high_pitched_beep).start()
                    threading.Thread(target=send_whatsapp_alert).start()
                    print("Fire detected for more than 3 seconds! Beeping and attempting to send alert!")
                    detection_start_time = current_time
            else:
                detection_start_time = None

            cv2.imshow("Fire and Smoke Detection", frame)

        except Exception as e:
            print(f"An error occurred in the main loop: {e}")
            cv2.imshow("Fire and Smoke Detection", frame)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
    else:
        break

cap.release()
cv2.destroyAllWindows()