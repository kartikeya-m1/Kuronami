Instructions to Set Up and Run Node.js + Python YOLO Detection System


Step 1: Navigate to the project directory
Open a terminal.
cd path/to/kuronami-main
Replace path/to/kuronami-main with the actual path where your project folder is located.

Step 2: Install required Node.js packages
In the kuronami-main directory, install the required Node.js and Express.js packages.


npm install
Ensure you have a valid package.json file with all required dependencies (like express) for the installation to succeed. If there’s no package.json file, create one with:


npm init -y
Then, install express and any other required middleware:


npm install express




Step 3: Run the Node.js server
After the installation completes, start the Node.js server by running:


node server.js


Step 4: Install Python dependencies for the YOLO detection system

pip install opencv-python numpy tensorflow




Step 5: Run the Python YOLO detection system
Once all Python dependencies are installed, start the YOLO detection system by running pyServ.py:

python pyServ.py
This will initiate the YOLO detection backend, which handles video input processing using the provided model.



Step 6: Split the terminal to run both processes
Split your terminal into two panes to run both the Node.js server and the Python YOLO detection backend simultaneously:

In one pane, run the Node.js server (node server.js).
In the other pane, run the Python YOLO backend (python pyServ.py).
Alternatively:
Open two separate terminals if your terminal doesn't support splits.
Step 7: Open index.html and start the live server
Open the index.html file from the kuronami-main project in your code editor.



Use a live server extension (like in VSCode) to serve the index.html file. You can use the Live Server extension or manually open the file in a browser.


Once it’s running, you should see a front-end interface where you can upload a video file.



Step 8: Upload the video file for YOLO detection
In the hosted web interface, upload the video file.

The Python backend (running locally) will start processing the video using the YOLO model for object detection.
Step 9: Verify the YOLO detection system
A YOLO object detection window should open (via OpenCV) and start showing detections on the uploaded video.
Ensure the detection window is not minimized to view the live detection feed.
Key Considerations



Resource-intensive models: Since YOLO models can be computationally expensive, running it directly on the web could lead to performance issues like frame dropping or crashing. Instead, the detection runs on the backend (local machine), and the front end (web interface) handles video uploads.

This separation prevents resource strain and ensures smooth performance.



""""NOTE INCLUDE ALL THE EXTRACTED MODEL FILES IN THIS FOLDER AND CHANGE THE PATH TO THE MODELS IN THE "pyserv.py" """"