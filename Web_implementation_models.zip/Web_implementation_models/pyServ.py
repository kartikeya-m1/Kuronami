


from flask import Flask, jsonify, request
import threading
import cv2
from ultralytics import YOLO
import torch
import time
import winsound
from twilio.rest import Client
from twilio.base.exceptions import TwilioRestException

app = Flask(__name__)

# Force CPU usage
torch.cuda.is_available = lambda: False

# Load the YOLOv8 models
fire_model = YOLO('C:/Users/gorakh/Downloads/Kuronami-main/Kuronami-main/Fire/best.pt')  # Fire detection model
accident_model = YOLO('C:/Users/gorakh/Downloads/Kuronami-main/Kuronami-main/Road/best.pt')  # Accident detection model
violence_model = YOLO('C:/Users/gorakh/Downloads/Kuronami-main/Kuronami-main/Violence/best (9).pt')  # Violence detection model

# Twilio configuration
account_sid = 'AC3d79a45eae5a8b158af85c6331f884f7'
auth_token = 'feb96f607a8d6b985c9ce6d2516d8b4a'
client = Client(account_sid, auth_token)
from_whatsapp_number = 'whatsapp:+14155238886'
to_whatsapp_number = 'whatsapp:+919764817663'

# Detection tracking variables
fire_detected = False
fire_detection_start_time = None
fire_detection_threshold = 3  # seconds

accident_detected = False
accident_detection_start_time = None
accident_detection_threshold = 3  # seconds

violence_detected = False
violence_detection_start_time = None
violence_detection_threshold = 3  # seconds

# Function to draw detection boxes on the frame
def draw_box(img, box, label, conf, color):
    x1, y1, x2, y2 = box
    thickness = 2

    # Draw the main rectangle with a thicker border
    cv2.rectangle(img, (int(x1), int(y1)), (int(x2), int(y2)), color, thickness)

    # Display label text with background for better visibility
    label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 1)[0]
    label_x1, label_y1 = int(x1), int(y1) - label_size[1] - 5
    label_x2, label_y2 = int(x1) + label_size[0], int(y1)
    
    # Draw a filled rectangle for text background
    cv2.rectangle(img, (label_x1, label_y1), (label_x2, label_y2), color, cv2.FILLED)
    
    # Draw the label text
    cv2.putText(img, label, (int(x1), int(y1) - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

    # Draw a confidence bar to the side of the box
    bar_x = int(x2) + 5
    bar_y = int(y1)
    bar_height = int(y2) - int(y1)
    filled_height = int(bar_height * conf)  # Filled portion based on confidence
    cv2.rectangle(img, (bar_x, bar_y), (bar_x + 10, bar_y + bar_height), (128, 128, 128), 1)  # Outline
    cv2.rectangle(img, (bar_x, bar_y + bar_height - filled_height), (bar_x + 10, bar_y + bar_height), color, cv2.FILLED)  # Filled portion

# Beep sound alert
def high_pitched_beep():
    frequency = 1500  # Set Frequency To 1500 Hertz
    duration = 3000   # Set Duration To 3000 ms == 3 seconds
    winsound.Beep(frequency, duration)

# Twilio WhatsApp alert
def send_whatsapp_alert(alert_type):
    try:
        message = client.messages.create(
            body=f'{alert_type} detected for more than {fire_detection_threshold} seconds!',
            from_=from_whatsapp_number,
            to=to_whatsapp_number
        )
        print(f"WhatsApp alert sent: {message.sid}")
    except TwilioRestException as e:
        print(f"Failed to send WhatsApp alert: {str(e)}")
    except Exception as e:
        print(f"An unexpected error occurred while sending WhatsApp alert: {str(e)}")

# Function to display predictions with improved visuals
def display_predictions(frame, results, detection_type):
    global violence_detected, violence_detection_start_time, accident_detected, accident_detection_start_time

    for r in results:
        boxes = r.boxes.xyxy
        confs = r.boxes.conf
        classes = r.boxes.cls

        for i in range(len(boxes)):
            box = boxes[i].cpu().numpy().astype(int)
            conf = confs[i].cpu().numpy()
            class_id = int(classes[i].cpu().numpy())

            x1, y1, x2, y2 = box

            if detection_type == "violence":
                if class_id == 1:  # Assuming class_id 1 corresponds to violence
                    color = (0, 0, 255)
                    label = f'Violence: {conf:.2f}'
                    violence_detected = True
                    if violence_detection_start_time is None:
                        violence_detection_start_time = time.time()
                else:
                    color = (0, 255, 0)
                    label = f'Non-Violence: {conf:.2f}'
                    violence_detected = False
                    violence_detection_start_time = None

            elif detection_type == "accident":
                if class_id == 0:  # Assuming class_id 0 corresponds to accident
                    color = (0, 0, 255)
                    label = f'Accident: {conf:.2f}'
                    accident_detected = True
                    if accident_detection_start_time is None:
                        accident_detection_start_time = time.time()
                else:
                    color = (0, 255, 0)
                    label = f'No Accident: {conf:.2f}'
                    accident_detected = False
                    accident_detection_start_time = None

            draw_box(frame, (x1, y1, x2, y2), label, conf, color)

    return frame

# Route to start fire detection
@app.route('/start_fire_detection', methods=['POST'])
def start_fire_detection():
    global fire_detected, fire_detection_start_time

    video_path = request.json.get("video_path", "C:/Users/gorakh/Downloads/Kuronami-main/Kuronami-main/Fire/Fire demo.mp4")
    
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return jsonify({"error": "Could not open video file"}), 400

    def fire_detection_loop():
        while cap.isOpened():
            success, frame = cap.read()
            if success:
                results = fire_model(frame, device='cpu')

                fire_detected = False
                for r in results:
                    for box in r.boxes:
                        x1, y1, x2, y2 = box.xyxy[0].tolist()
                        conf = float(box.conf)
                        cls = int(box.cls)
                        class_name = fire_model.names[cls]

                        label = f"{class_name} {conf:.2f}"

                        if class_name.lower() == 'fire':
                            color = (0, 0, 255)
                            fire_detected = True
                        elif class_name.lower() == 'smoke':
                            color = (128, 128, 128)
                        else:
                            color = (0, 255, 0)

                        draw_box(frame, (x1, y1, x2, y2), label, conf, color)

                current_time = time.time()
                if fire_detected:
                    if fire_detection_start_time is None:
                        fire_detection_start_time = current_time
                    elif current_time - fire_detection_start_time >= fire_detection_threshold:
                        threading.Thread(target=high_pitched_beep).start()
                        threading.Thread(target=send_whatsapp_alert, args=("Fire",)).start()
                        print("Fire detected for more than 3 seconds! Beeping and attempting to send alert!")
                        fire_detection_start_time = current_time
                else:
                    fire_detection_start_time = None

                cv2.imshow("Fire and Smoke Detection", frame)

            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

        cap.release()
        cv2.destroyAllWindows()

    threading.Thread(target=fire_detection_loop).start()

    return jsonify({"message": "Fire detection started."}), 200

# Route to start accident detection
@app.route('/start_accident_detection', methods=['POST'])
def start_accident_detection():
    global accident_detected, accident_detection_start_time
    
    video_path = request.json.get("video_path", "testing.mp4")
    cap = cv2.VideoCapture(video_path)

    if not cap.isOpened():
        return jsonify({'error': f'Error: Could not open video file {video_path}'}), 400

    def accident_detection_loop():
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                print("End of video or error: Failed to capture image")
                break

            results = accident_model(frame, device='cpu')
            frame = display_predictions(frame, results, detection_type="accident")

            current_time = time.time()
            if accident_detected:
                if accident_detection_start_time is None:
                    accident_detection_start_time = current_time
                elif current_time - accident_detection_start_time >= accident_detection_threshold:
                    threading.Thread(target=high_pitched_beep).start()
                    try:
                        client.messages.create(
                            body="Emergency Alert: Accident detected!",
                            from_=from_whatsapp_number,
                            to=to_whatsapp_number
                        )
                        print("WhatsApp message sent")
                    except Exception as e:
                        print(f"Failed to send message: {str(e)}")
                    accident_detection_start_time = current_time
            else:
                accident_detection_start_time = None

            cv2.imshow('YOLOv8 Real-time Accident Detection', frame)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()

    threading.Thread(target=accident_detection_loop).start()

    return jsonify({'status': 'Detection started for accidents.'}), 200

# Route to start violence detection
@app.route('/start_violence_detection', methods=['POST'])
def start_violence_detection():
    global violence_detected, violence_detection_start_time

    video_path = request.json.get("video_path", "demo2.mp4")
    cap = cv2.VideoCapture(video_path)

    if not cap.isOpened():
        return jsonify({'error': f'Error: Could not open video file {video_path}'}), 400

    def violence_detection_loop():
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                print("End of video or error: Failed to capture image")
                break

            results = violence_model(frame, device='cpu')
            frame = display_predictions(frame, results, detection_type="violence")

            current_time = time.time()
            if violence_detected:
                if violence_detection_start_time is None:
                    violence_detection_start_time = current_time
                elif current_time - violence_detection_start_time >= violence_detection_threshold:
                    threading.Thread(target=high_pitched_beep).start()
                    try:
                        client.messages.create(
                            body="Emergency Alert: Violence detected!",
                            from_=from_whatsapp_number,
                            to=to_whatsapp_number
                        )
                        print("WhatsApp message sent")
                    except Exception as e:
                        print(f"Failed to send message: {str(e)}")
                    violence_detection_start_time = current_time
            else:
                violence_detection_start_time = None

            cv2.imshow('YOLOv8 Real-time Violence Detection', frame)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()

    threading.Thread(target=violence_detection_loop).start()

    return jsonify({'status': 'Violence detection started.'}), 200

# Run the Flask application
if __name__ == '__main__':
    app.run(debug=True, port=7070)
