// const express = require("express");
// const axios = require("axios");
// const cors = require("cors");

// const app = express();
// const PORT = process.env.PORT || 3000;

// // Enable CORS and JSON parsing
// app.use(cors());
// app.use(express.json());

// // POST route to start fire detection
// app.post("/start_fire_detection", async (req, res) => {
// 	const videoPath = req.body.video_path || "Fire//Fire demo.mp4"; // Default video path

// 	try {
// 		const response = await axios.post(
// 			"http://localhost:7070/start_fire_detection",
// 			{ video_path: videoPath }
// 		);
// 		res.json(response.data);
// 	} catch (error) {
// 		console.error(`Error: ${error.message}`);
// 		res.status(500).json({ error: "Failed to start fire detection" });
// 	}
// });

// // POST route to start accident detection
// app.post("/start_accident_detection", async (req, res) => {
// 	const videoPath = req.body.video_path || "Road//testing.mp4"; // Default video path

// 	try {
// 		const response = await axios.post(
// 			"http://localhost:7070/start_accident_detection",
// 			{ video_path: videoPath }
// 		);
// 		res.json(response.data);
// 	} catch (error) {
// 		console.error(`Error: ${error.message}`);
// 		res.status(500).json({ error: "Failed to start accident detection" });
// 	}
// });

// // POST route to start violence detection
// app.post("/start_violence_detection", async (req, res) => {
// 	const videoPath = req.body.video_path || "Violence//demo2.mp4"; // Default video path

// 	try {
// 		const response = await axios.post(
// 			"http://localhost:7070/start_violence_detection",
// 			{ video_path: videoPath }
// 		);
// 		res.json(response.data);
// 	} catch (error) {
// 		console.error(`Error: ${error.message}`);
// 		res.status(500).json({ error: "Failed to start violence detection" });
// 	}
// });

// // Start the Express server
// app.listen(PORT, () => {
// 	console.log(`Server running on http://localhost:${PORT}`);
// });



const express = require("express");
const axios = require("axios");
const cors = require("cors");
const multer = require("multer");
const path = require("path");

const app = express();
const PORT = 3000;

// Enable CORS and JSON parsing
app.use(cors());
app.use(express.json());

// Set up multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}_${file.originalname}`);
    }
});

const upload = multer({ storage });

// Routes for uploading and starting detection

// Fire Detection
app.post("/upload_fire_detection", upload.single('video'), async (req, res) => {
    const videoPath = req.file ? req.file.path : "uploads/default_fire.mp4";
    try {
        const response = await axios.post("http://localhost:7070/start_fire_detection", {
            video_path: videoPath
        });
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: "Failed to start fire detection" });
    }
});

// Accident Detection
app.post("/upload_accident_detection", upload.single('video'), async (req, res) => {
    const videoPath = req.file ? req.file.path : "uploads/default_accident.mp4";
    try {
        const response = await axios.post("http://localhost:7070/start_accident_detection", {
            video_path: videoPath
        });
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: "Failed to start accident detection" });
    }
});

// Violence Detection
app.post("/upload_violence_detection", upload.single('video'), async (req, res) => {
    const videoPath = req.file ? req.file.path : "uploads/default_violence.mp4";
    try {
        const response = await axios.post("http://localhost:7070/start_violence_detection", {
            video_path: videoPath
        });
        res.json(response.data);
    } catch (error) {
        res.status(500).json({ error: "Failed to start violence detection" });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
