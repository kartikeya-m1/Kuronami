

import cv2
from ultralytics import YOLO
import torch
import numpy as np
from twilio.rest import Client
import time
import threading
import winsound

# Load the YOLOv8 model (trained with best.pt)
model = YOLO('Road_accident/best.pt')  # Replace with actual path to your best.pt

# Open video file
video_path = "Road_accident/testing2.mp4"
cap = cv2.VideoCapture(video_path)

if not cap.isOpened():
    print(f"Error: Could not open video file {video_path}")
    exit()

# Twilio setup
TWILIO_ACCOUNT_SID = 'AC3d79a45eae5a8b158af85c6331f884f7'
TWILIO_AUTH_TOKEN = 'feb96f607a8d6b985c9ce6d2516d8b4a'
TWILIO_WHATSAPP_NUMBER = 'whatsapp:+14155238886'
EMERGENCY_WHATSAPP_NUMBER = 'whatsapp:+919764817663'

client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

# Initialize variables for accident detection
accident_detected = False
detection_start_time = None

def high_pitched_beep():
    frequency = 1500  # Set Frequency To 1500 Hertz for a high-pitched sound
    duration = 3000   # Set Duration To 3000 ms == 3 seconds
    winsound.Beep(frequency, duration)  # Play the beep sound

# Define a function to display YOLO predictions on the frame
def display_predictions(frame, results):
    global accident_detected, detection_start_time

    for r in results:
        boxes = r.boxes.xyxy
        confs = r.boxes.conf
        classes = r.boxes.cls

        for i in range(len(boxes)):
            box = boxes[i].cpu().numpy().astype(int)
            conf = confs[i].cpu().numpy()
            class_id = int(classes[i].cpu().numpy())

            x1, y1, x2, y2 = box
            
            # Assuming class_id 0 is for accidents (adjust if needed)
            if class_id == 0:
                color = (0, 0, 255)  # Red for accidents
                label = f'Accident: {conf:.2f}'
                accident_detected = True
                
                # Start timer if accident is detected for the first time
                if detection_start_time is None:
                    detection_start_time = time.time()
            else:
                color = (0, 255, 0)  # Green for non-accidents
                label = f'Non-Accident: {conf:.2f}'
                accident_detected = False
                detection_start_time = None  # Reset timer

            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

    return frame

# Process the video until the user presses 'q'
while True:
    ret, frame = cap.read()
    if not ret:
        print("End of video or failed to grab frame")
        break

    # Resize frame for faster processing
    frame = cv2.resize(frame, (640, 480))

    results = model(frame, device='cpu')
    frame = display_predictions(frame, results)

    # Check if accident has been detected for more than 3 seconds
    if accident_detected and detection_start_time is not None:
        elapsed_time = time.time() - detection_start_time
        
        if elapsed_time > 3:
            threading.Thread(target=high_pitched_beep).start()  # Start beep in a separate thread
            
            # Send WhatsApp message via Twilio
            message_body = "Emergency Alert: Accident detected!"
            try:
                message = client.messages.create(
                    body=message_body,
                    from_=TWILIO_WHATSAPP_NUMBER,
                    to=EMERGENCY_WHATSAPP_NUMBER
                )
                print(f"WhatsApp message sent. Message SID: {message.sid}")
            except Exception as e:
                print(f"Error sending WhatsApp message: {str(e)}")
            
            # Reset detection variables after alerting
            accident_detected = False
            detection_start_time = None

    cv2.imshow('YOLOv8 Real-time Accident Detection', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()